"""Tests for formatters and safety helpers (no cluster required)."""
from __future__ import annotations

from k8s_mcp.formatters import (
    _compact,
    describe,
    mask_secret_data,
    short_table,
    to_yaml,
)


def test_to_yaml_basic():
    obj = {"apiVersion": "v1", "kind": "Pod", "metadata": {"name": "p"}}
    out = to_yaml(obj)
    assert "kind: Pod" in out
    assert "name: p" in out


def test_mask_secret_data_masks_data_and_stringdata():
    secret = {
        "apiVersion": "v1",
        "kind": "Secret",
        "metadata": {"name": "creds"},
        "data": {"password": "YWRtaW4="},
        "stringData": {"token": "abc"},
    }
    masked = mask_secret_data(secret)
    assert masked["data"] == {"password": "***"}
    assert masked["stringData"] == {"token": "***"}
    # non-secret fields untouched
    assert masked["metadata"]["name"] == "creds"


def test_mask_secret_data_non_secret_untouched():
    cm = {"kind": "ConfigMap", "data": {"k": "v"}}
    assert mask_secret_data(cm) == cm


def test_short_table_empty():
    assert short_table([], ["NAME"]) == "(empty)"


def test_short_table_columns_and_alignment():
    rows = [
        {"NAME": "a", "STATUS": "Running"},
        {"NAME": "longer-name", "STATUS": "Pending"},
    ]
    out = short_table(rows, ["NAME", "STATUS"])
    lines = out.split("\n")
    header = lines[0].rstrip()
    assert header.startswith("NAME")
    assert header.endswith("STATUS")
    assert "a" in lines[2]
    assert "longer-name" in lines[3]


def test_describe_basic():
    obj = {
        "apiVersion": "apps/v1",
        "kind": "Deployment",
        "metadata": {
            "name": "web",
            "namespace": "default",
            "labels": {"app": "web"},
            "creationTimestamp": "2026-01-01T00:00:00Z",
        },
        "spec": {"replicas": 3, "selector": {"matchLabels": {"app": "web"}}},
        "status": {"readyReplicas": 3, "replicas": 3},
    }
    out = describe(obj)
    assert "Name:       web" in out
    assert "Namespace:  default" in out
    assert "Kind:       Deployment" in out
    assert "replicas: 3" in out


def test_compact_truncation():
    big = {"x": "y" * 500}
    out = _compact(big, max_len=50)
    assert out.endswith("...")
    assert len(out) <= 50
